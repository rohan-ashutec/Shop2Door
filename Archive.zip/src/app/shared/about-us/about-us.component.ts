import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';

@Component({
  selector: 'app-about-us',
  templateUrl: './about-us.component.html',
  styleUrls: ['./about-us.component.scss'],
})
export class AboutUsComponent implements OnInit {

    private menuController: MenuController
    constructor() { }

  ngOnInit() {}
  openMenu() {
    this.menuController.open();
  }
}
